package com.example.fruitapplication2.ui.manggis;

import androidx.lifecycle.ViewModel;

public class ManggisViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}