package com.example.fruitapplication2.ui.rambutan;

import androidx.lifecycle.ViewModel;

public class RambutanViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}