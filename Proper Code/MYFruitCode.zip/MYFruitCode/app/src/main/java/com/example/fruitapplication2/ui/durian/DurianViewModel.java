package com.example.fruitapplication2.ui.durian;

import androidx.lifecycle.ViewModel;

public class DurianViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}