package com.example.fruitapplication2.ui.otaheite;

import androidx.lifecycle.ViewModel;

public class OtaheiteViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}