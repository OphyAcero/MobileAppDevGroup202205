package com.example.fruitapplication2.ui.langsat;

import androidx.lifecycle.ViewModel;

public class LangsatViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}